package com.control;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.dao.UserCredDao;
import com.dao.UserDao;
import com.model.UserCredential;
import com.model.UserDetails;



@Controller

public class RegisterController {
   
@Autowired 
UserDao userD;
@Autowired
UserCredDao userCrd;
	@RequestMapping(value = "/addRegister", method = RequestMethod.POST)  
	public ModelAndView addRegister(UserDetails user) { 
		
		String pass= user.getPassword();
		String userName= user.getName();
		String role= "ROLE_USER";
		boolean en=true;
	    userD.addUser(user);
	    UserCredential userDrc= new UserCredential(); //model
	    userDrc.setUserName(userName); userDrc.setPassword(pass); userDrc.setRole(role);userDrc.setEnabled(en);
	    userCrd.addUserCred(userDrc);
	    ModelAndView m= new ModelAndView("Thanks","UserDetails", new UserDetails());
	    m.addObject("userData",user);
		return m;
	}
	
	
		@RequestMapping( value="/Register" ,method = RequestMethod.GET)
	   public ModelAndView dispalUser() {
			return new ModelAndView("Register","UserDetails", new UserDetails() );
	   }
		





}
