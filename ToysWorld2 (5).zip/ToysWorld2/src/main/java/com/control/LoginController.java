package com.control;

import java.util.ArrayList;
import java.util.Collection;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.dao.LoginDao;
import com.dao.ProductDao;
import com.dao.UserDao;
import com.model.ShopCart;

@Controller
public class LoginController {

	@Autowired
	LoginDao loginDao;
	@Autowired

	ProductDao proDao;


	@RequestMapping("/AboutUs")
	public String showAboutUs() {
		return "AboutUs";
	}

	@RequestMapping("/Home")
	public String showHome() {

		return "index";
	}

	// ------------------------------------------------
	@RequestMapping(value = "/Login", method = RequestMethod.GET)
	public String displayLogin() {
		return "Login";
	}

	@RequestMapping("/perform_logout")
	public String logOut() {
		System.out.println("at Loggggggggggg out");
		return "Login";
	}

	@RequestMapping(value = "/login_session_attributes")
	public String login_session_attributes(HttpSession session, Model model) {

		String userid = SecurityContextHolder.getContext().getAuthentication().getName();
		Collection<GrantedAuthority> authorities = (Collection<GrantedAuthority>) SecurityContextHolder.getContext()
				.getAuthentication().getAuthorities();

		String page = "";
		String role = "ROLE_USER";
		for (GrantedAuthority authority : authorities) {

			if (authority.getAuthority().equals(role)) {
				session.setAttribute("UserLoggedIn", "true");
				String data = proDao.getAllProduct();

				model.addAttribute("proList", data);
				session.setAttribute("LoggedIn", "true");
				session.setAttribute("user", userid);
				System.out.println("Login Session User");
              
				
				
				ArrayList<ShopCart> ob = new ArrayList<ShopCart>();
				session.setAttribute("mycart", ob);
				System.out.println("List session " + ob);
				page = "Product";
				// session.setAttribute("cartsize", cartDAO.cartsize((int)
				// session.getAttribute("userId")));
			} else {
				session.setAttribute("Administrator", "true");
				session.setAttribute("user", userid);
				System.out.println("Admin Session started");
				page = "AdminHome";
			}
		}
		return page;

	}

	//
	// //session.setAttribute("LoggedIn", "true");
	//
	//
	// for (GrantedAuthority authority : authorities)
	// {
	//
	// if (authority.getAuthority().equals(role))
	// {
	// String jsondata= aDAO.listAdProd();
	// model.addAttribute("dat",jsondata);
	// session.setAttribute("UserLoggedIn", "true");
	// session.setAttribute("userid",userName);
	// //page="Cart";
	// page="ShowProduct";
	// ArrayList<CartDetail> ob = new ArrayList<CartDetail>();
	// session.setAttribute("mycart",ob);
	// //
	// session.setAttribute("cartsize",cartDAO.cartsize((int)session.getAttribute("userId")));
	// }
	// else
	// {
	// session.setAttribute("Administrator", "true");
	// session.setAttribute("userid",userName);
	// page="AdminLogin";
	//
	// }
	// }
	// return page;
	// }
	//

	// @RequestMapping( value="/Login" ,method = RequestMethod.POST)
	// public String displayLog() {
	// return "";
	// }
	//

	//// @RequestMapping("/ContactUs")
	//// public String showContactUs()
	//// {
	//// return "Contact";
	//// }
	////
	//// @RequestMapping("/Login")
	//// public String showLogin()
	//// {
	//// return "Login";
	//// }
	//// -----------------------------------------
	//// @RequestMapping("/Product")
	//// public String showProduct()
	//// {
	//// return "Product";
	//// }
	//
	//// @RequestMapping("/Register")
	//// public String showRegister()
	//// {
	////
	//// return "Register";
	//// }
	////
	//
}
