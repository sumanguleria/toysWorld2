package com.control;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.dao.CartDao;
import com.dao.ProductDao;
import com.dao.UserDao;
import com.google.gson.Gson;

import com.model.Category;
import com.model.Product;
import com.model.ShopCart;
import com.model.UserDetails;

@Controller
public class CartController {

	@Autowired
	CartDao cartDao;
	@Autowired
	ProductDao proDao;


	@Autowired
	UserDao userObj;
	@RequestMapping(value = "/addtoCart", method = RequestMethod.GET)
	public ModelAndView viewCart(@RequestParam("id") int id, HttpSession session) {

		Product p = proDao.getRowById(id);
		ShopCart c = new ShopCart();

		c.setpId(p.getItemID());
		c.setItemName(p.getItemName());
		c.setPrice(p.getPrice());

		List<ShopCart> li = (ArrayList<ShopCart>) session.getAttribute("mycart");
		li.add(c);
		Gson gsonList = new Gson();
		String gs = gsonList.toJson(li);
		ModelAndView m = new ModelAndView("CartPage", "ShopCart", new ShopCart());
		m.addObject("cart", gs);
		System.out.println("after view Cart" + session.getAttribute("mycart"));
		return m;

	}

	@RequestMapping(value = "/DelCartItem", method = RequestMethod.GET)
	public ModelAndView DelCartItem(@RequestParam("id") int id, HttpSession session) {
		List<ShopCart> ld = (ArrayList<ShopCart>) session.getAttribute("mycart");

		// d=li.get(id);
		// System.out.println(d);
		// System.out.println(li.indexOf(id));
		// session.removeAttribute("cid");
		// cDAO.remcart(cid);

		ListIterator<ShopCart> lit = (ListIterator<ShopCart>) ld.listIterator();
		while (lit.hasNext()) {
			ShopCart d = lit.next();
			if (d.getpId() == id) {
				System.out.println(ld.indexOf(d));
				ld.remove(ld.indexOf(d)); // removing data from session List
				break;
			}
		}
		session.setAttribute("mycart", ld); // again added data into session
		ModelAndView mv = new ModelAndView("CartPage", "ShopCart", new ShopCart());
		Gson gsonli = new Gson();
		String gs = gsonli.toJson(ld); // converinting again data into gson
		mv.addObject("cart", gs);
		return mv;

	}
	
@RequestMapping(value="/OrderConform")
public ModelAndView showOrderPage(HttpSession session)
{
	
	

	
	
	List<ShopCart> shoList = (ArrayList<ShopCart>) session.getAttribute("mycart");
	Gson g= new Gson();
	String data= g.toJson(shoList);
	System.out.print("Shop data in Order"+data);
	 ModelAndView m= new ModelAndView("OrderConformation","ShopCart",new ShopCart());
	 m.addObject("cart",data);
	m.addObject("userAddr",userObj.getAddrByName(session.getAttribute("user").toString()));
	//m.addObject("userPhon",userObj.getPhonByName(session.getAttribute("user").toString()));
		
	return m;
}

	
@RequestMapping(value="/BackToCartPage")
public ModelAndView BackToCartPage(HttpSession session)
{
	List<ShopCart> shoList = (ArrayList<ShopCart>) session.getAttribute("mycart");
	Gson g= new Gson();
	String data= g.toJson(shoList);
	ModelAndView m= new ModelAndView("CartPage","ShopCart",new ShopCart());
	
	 m.addObject("cart",data);
	return m;

}
	
@RequestMapping(value="/PaymentPage")
public ModelAndView makePayment(HttpSession session)
{
	List<ShopCart> shoList = (ArrayList<ShopCart>) session.getAttribute("mycart");
	Gson g= new Gson();
	String data= g.toJson(shoList);
	ModelAndView m= new ModelAndView("PaymentPage");
	
	 m.addObject("cart",data);
	return m;

}

	// @RequestMapping(value = "/addtoCart", method = RequestMethod.POST)
	// public ModelAndView addtoCart(Cart cat) {
	// System.out.println("inside post");add
	//
	// ModelAndView m = new ModelAndView("CartPage", "Cart", new Cart());
	//
	// return m;
	//
	// }

}
