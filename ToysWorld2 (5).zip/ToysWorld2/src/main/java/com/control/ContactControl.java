package com.control;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.dao.ContactDao;
import com.model.Contact;
import com.model.Product;


@Controller
public class ContactControl {

	@Autowired 
	ContactDao conDao;
	
	@RequestMapping(value = "/Contact", method = RequestMethod.GET)  
	public String displayRegister(@ModelAttribute("Contact")Contact contact) { 
    return "Contact"; 
	}
	
	
	@RequestMapping(value = "/addContact", method = RequestMethod.POST)
	public ModelAndView addContact(Contact contact) {
		System.out.println("inside post saving data");
		conDao.addProduct(contact);
		ModelAndView m = new ModelAndView("Contact", "Contact", new Contact());		
	      return m;
	   }
	
	
	

}
