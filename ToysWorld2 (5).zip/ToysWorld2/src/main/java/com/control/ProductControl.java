package com.control;

import com.dao.CategoryDao;
import com.dao.ProductDao;
import com.dao.SupplierDao;
import com.google.gson.Gson;
import com.model.*;

import java.awt.SystemColor;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class ProductControl {

	@Autowired
	ProductDao proDao;

	@Autowired
	SupplierDao supDao;

	@Autowired
	CategoryDao catDao;

	@RequestMapping(value = "/AddProduct", method = RequestMethod.GET)
	public ModelAndView displayProduct() {
		System.out.print("Iside GET");
		ModelAndView m = new ModelAndView("AddProduct", "Product", new Product());
		String data = proDao.getAllProduct();
        String supData = supDao.viewSupplier();
		System.out.print(supData);
		String catData = catDao.listCategory();
		System.out.print("Category" + catData);
		m.addObject("supList", supData);
		m.addObject("catList", catData); 
		m.addObject("proList", data);
		System.out.println("Product Controller"+data);
		m.addObject("checked", true);
		return m;
	}

	@RequestMapping(value = "/addProduct", method = RequestMethod.POST)
	public ModelAndView addProduct(Product product) {
		System.out.println("inside post saving data");
		proDao.addProduct(product);
		//Image Uplaodaing code
		String path="E:\\mavenWorkpace\\ToysWorld2\\src\\main\\webapp\\resources\\img\\";
		path=path+String.valueOf(product.getItemID())+".jpg";
		File f=new File(path);
	
		MultipartFile filedet=product.getImage();
		
		if(!filedet.isEmpty())
		{
			try
			{
			  byte[] bytes=filedet.getBytes();
			  System.out.println(bytes.length);
			  FileOutputStream fos=new FileOutputStream(f);
              			BufferedOutputStream bs=new BufferedOutputStream(fos);
              			bs.write(bytes);
              			bs.close();
             			System.out.println("File Uploaded Successfully");
			}
			catch(Exception e)
			{
				System.out.println("Exception Arised"+e);
			}
		}
		else
		{
			System.out.println("File is Empty not Uploaded");
			
		}
		

		ModelAndView m = new ModelAndView("AddProduct", "Product", new Product());
		String data = proDao.getAllProduct();
		String supData = supDao.viewSupplier();
		String catData = catDao.listCategory();
		m.addObject("supList", supData);
		m.addObject("catList", catData);
		m.addObject("checked", true);
		m.addObject("proList", data);
		return m;

	}

	// method for when we click on update link

	@RequestMapping(value = "/editProduct", method = RequestMethod.GET)
	public ModelAndView updateProduct(@RequestParam("pId") int sp) {
		System.out.print("Iside getGET");
		Product product = proDao.getRowById(sp); // retrieve data

		ModelAndView m = new ModelAndView("AddProduct", "Product", product);
		String supData = supDao.viewSupplier();
		String catData = catDao.listCategory();
		
		m.addObject("supList", supData);
		m.addObject("catList", catData);
		String data = proDao.getAllProduct();
		m.addObject("proList", data);

		// m.addObject("proObject", product);
		m.addObject("checked", false);
		System.out.println(sp + "inside dispUpdateProduct ");

		return m;
	}

	// method for when we click on Update Button to update data
	@RequestMapping(value = "/updateProduct", method = RequestMethod.POST)
	public ModelAndView updateProduct(Product pObj) {
		int id = pObj.getItemID();
		System.out.println(id +"Inside update Product");
		
		String path="E:\\mavenWorkpace\\ToysWorld2\\src\\main\\webapp\\resources\\img\\";
		path=path+String.valueOf(pObj.getItemID())+".jpg";
		File f=new File(path);
	
		MultipartFile filedet=pObj.getImage();
		
		if(!filedet.isEmpty())
		{
			try
			{
			  byte[] bytes=filedet.getBytes();
			  System.out.println(bytes.length);
			  FileOutputStream fos=new FileOutputStream(f);
              			BufferedOutputStream bs=new BufferedOutputStream(fos);
              			bs.write(bytes);
              			bs.close();
             			System.out.println("File Uploaded Successfully");
			}
			catch(Exception e)
			{
				System.out.println("Exception Arised"+e);
			}
		}
		else
		{
			System.out.println("File is Empty not Uploaded");
			
		}
		
		proDao.updateProject(pObj, id);
		ModelAndView m = new ModelAndView("AddProduct", "Product", new Product()); // doubt
		String data = proDao.getAllProduct();
		String supData = supDao.viewSupplier();
		String catData = catDao.listCategory();
		m.addObject("supList", supData);
		m.addObject("catList", catData);
		m.addObject("proList", data);
		m.addObject("checked", true);
		
		//
		
		
		return m;

	}

	@RequestMapping(value = "/deleteProduct", method = RequestMethod.GET)
	public ModelAndView deleteProduct(@RequestParam("pId") int pId) {
		proDao.deleteProduct(pId);
		ModelAndView m = new ModelAndView("AddProduct", "Product", new Product());
		String data = proDao.getAllProduct();
		String supData = supDao.viewSupplier();
		System.out.print(supData);
		String catData = catDao.listCategory();
		System.out.print("Category" + catData);
		m.addObject("supList", supData);
		m.addObject("catList", catData);
		m.addObject("proList", data);
		m.addObject("checked", true);

		return m;

	}
	
	
	// for users Product 
	 @RequestMapping("/ViewProduct")
		 public ModelAndView viewProduct(){ 
		String data= proDao.getAllProduct();
		 System.out.println("View all Product "+data);
		 ModelAndView m= new ModelAndView("Product","Product",new Product());
		 m.addObject("proList",data);
		 return m;
		 }

		// method for when we click on update link

		@RequestMapping(value = "/showProductD", method = RequestMethod.GET)
		public ModelAndView showSelectedProduct(@RequestParam("imageId") int img) {
			System.out.print("Iside GET");
			Product pObject = proDao.getRowById(img); // retrieve data
			ModelAndView m = new ModelAndView("ShowProductDetail", "Product", new Product());
		
			  Gson g= new Gson();
			  String data=g.toJson(pObject);
               System.out.println(data);
               m.addObject("showData", data);
			return m;
		}
	 
	 
	 
	// -----------------------------------------All these are different ways to
	// do things---------------------working
	// @RequestMapping("/Product")
	// public ModelAndView viewProduct(){
	// List<Product> list=dao.addProduct();
	// return new ModelAndView("Product","list",list);
	// }

	// ---List ---------------to JSON Conversion
	// @RequestMapping("/Product")
	// public String viewProduct(Model m) {
	// List<Product> list = dao.addProduct();
	// Gson g = new Gson();
	// String json = g.toJson(list);
	// m.addAttribute("proList", json);
	// return "Product";
	// }
	//

	// @RequestMapping("/Product")
	// public @ResponseBody
	// List viewProduct(){
	// List<Product> list=dao.addProduct();
	// System.out.println(list);
	// return list;
	// }

	// ----------------------------------------------------------------

}
