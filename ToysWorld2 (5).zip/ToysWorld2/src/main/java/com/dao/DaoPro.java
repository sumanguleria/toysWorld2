package com.dao;
import com.model.*;
import java.util.*;
public interface DaoPro {

	   public void addProduct(Product pro);
	    public List<Product> getAllProduct();
	    public void deleteProduct(Integer productId);

}
