package com.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.model.Category;
import com.model.Login;

@Repository
public class LoginDao {
	@Autowired
	SessionFactory sessionFactory;
	
	public Login getRowById(String user) {
		Session session = sessionFactory.openSession();
		Login log = (Login) session.load(Login.class, user);
		session.close();
		return log;
	}

}
