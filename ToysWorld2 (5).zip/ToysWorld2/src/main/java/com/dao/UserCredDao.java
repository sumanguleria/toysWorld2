package com.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.model.Product;
import com.model.UserCredential;

@Repository
public class UserCredDao {
	@Autowired
	SessionFactory sessionFactory;
	
	@Transactional
	public void addUserCred(UserCredential userC) {
		Session ses = sessionFactory.openSession();
		ses.beginTransaction();
		ses.save(userC);
		System.out.println("Saveddddd  User crediental data");
		ses.getTransaction().commit();
		ses.close();
		// SessionsessionFactory.getCurrentSession().save(pro);
	}

}
