package com.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.model.Product;
import com.model.UserDetails;

@Repository
public class UserDao {

	@Autowired
	SessionFactory sessionFactory;
	
	@Transactional
	public void addUser(UserDetails user) {
		Session ses = sessionFactory.openSession();
		ses.beginTransaction();
		ses.save(user);
		System.out.println("Saveddddd  User Deatils data");
		ses.getTransaction().commit();
		ses.close();
		// SessionsessionFactory.getCurrentSession().save(pro);
	}

	public String getAddrByName(String userName) {
	Session ses = sessionFactory.openSession();
	Criteria c= ses.createCriteria(UserDetails.class);
	String result=((UserDetails)c.add(Restrictions.ilike("username",userName)).list().get(0)).getAddress();
	return result;
		
	}
	
	//????????????????????
//	public String getPhonByName(String userName) {
//		Session ses = sessionFactory.openSession();
//		Criteria c= ses.createCriteria(UserDetails.class);
//		c.add(Restrictions.i)
//		String result=((UserDetails)c.add(Restrictions.ilike("phon",userName)).list().get(0)).getPhon();
//		return result;
//			
//		}
}
