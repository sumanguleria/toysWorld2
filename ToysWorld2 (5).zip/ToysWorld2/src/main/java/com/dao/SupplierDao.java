package com.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.google.gson.Gson;
import com.model.Supplier;

@Repository
public class SupplierDao {
	// step1
	@Autowired
	SessionFactory sessionFactory;

	public void addSup(Supplier sObj) {
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		session.save(sObj);
		session.getTransaction().commit();
		session.close();
	}

	public String viewSupplier() {
		Session ses = sessionFactory.openSession();
		List sList = ses.createQuery("from Supplier").list();
		Gson g = new Gson();
		String data = g.toJson(sList);
		ses.close();
		return data;

	}

	public Supplier viewSupplierById(int supId) {
		Session ses = sessionFactory.openSession();
		Supplier supObj = (Supplier) ses.get(Supplier.class, supId);
		
		ses.close();
		return supObj;

	}

	public void updateSupplier(Supplier sObj, int supId) {
		Session ses = sessionFactory.openSession();
		ses.beginTransaction();
		Supplier supObj = (Supplier) ses.get(Supplier.class, supId);
		supObj.setSupplierName(sObj.getSupplierName());
		supObj.setSupplierAddr(sObj.getSupplierAddr());
		ses.update(supObj);
		ses.getTransaction().commit();
		ses.close();
	}

	
	public void deleteSupplier(int supId) {
		Session s = sessionFactory.openSession();
		s.beginTransaction();
		Supplier spObj = (Supplier) s.get(Supplier.class, supId);
		s.delete(spObj);
		s.getTransaction().commit();
		System.out.println("Data deleted " + supId);
		s.close();
	}

}
