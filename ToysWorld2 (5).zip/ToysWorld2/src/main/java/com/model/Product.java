package com.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

@Entity
public class Product {

@Id
@GeneratedValue
@Column(name="Product_Id")
int itemID;

	@Column(name="Product_Name")
	String itemName;
	@Column(name="PRO_Description")
	String discription;
	@Column(name="Quantity")
	int qty;
	
	@Column(name="Price")
	double price;
	
	@Transient
	MultipartFile image;
	int categoryId,supplierId;
	
	
	
	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public int getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(int supplierId) {
		this.supplierId = supplierId;
	}

	public Product()
	{
		
	}
	
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public int getItemID() {
		return itemID;
	}
	public void setItemID(int itemID) {
		this.itemID = itemID;
	}
	public String getDiscription() {
		return discription;
	}
	public void setDiscription(String discription) {
		this.discription = discription;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}

	public MultipartFile getImage() {
		return image;
	}

	public void setImage(MultipartFile image) {
		this.image = image;
	}	

	
	
	
//	public Product(String itemName, int itemID, String discription, int qty, double price, String image) {
//	
//	this.itemName = itemName;
//	this.itemID = itemID;
//	this.discription = discription;
//	this.qty = qty;
//	this.price = price;
//	this.image = image;
//}
//
	
	}
