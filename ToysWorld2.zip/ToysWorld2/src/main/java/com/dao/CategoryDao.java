package com.dao;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.ietf.jgss.GSSException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.google.gson.Gson;
import com.model.Category;
import com.model.Product;

@Repository
public class CategoryDao {

	@Autowired
	SessionFactory sessionFactory;

	// @Transactional
	public void addCategory(Category cat) {
		Session ses = sessionFactory.openSession();
		ses.beginTransaction();
		ses.save(cat);
		System.out.println("saved category data");
		ses.getTransaction().commit();
		ses.close();
	}

	public String listCategory() {
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		List catList = session.createQuery("from Category").list();
		Gson jsonObj = new Gson();
		String data = jsonObj.toJson(catList);
		System.out.println(data);
		session.getTransaction().commit();
		session.close();
		return data;
	}

	public void removeCat(int id) {
		Session session = this.sessionFactory.openSession();
		session.beginTransaction();
		Category p = (Category) session.get(Category.class, id);
		session.delete(p);
		session.getTransaction().commit();
		session.close();

		System.out.println("Category deleted successfully,=" + p);
	}

	// ---------------Update Data ----------------------------- it was working
	// public int updateCategory(int catId) {
	// Session session = this.sessionFactory.openSession();
	// session.beginTransaction();
	// Category p = (Category) session.get(Category.class,catId);
	// session.update(p);
	// session.getTransaction().commit();
	//
	// System.out.println("Category updated successfully, =" + catId);
	//
	//
	// return p;
	// }

	public int updateRow(Category category) {
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		session.saveOrUpdate(category);
		session.getTransaction().commit();
		Serializable id = session.getIdentifier(category);
		session.close();
		return (Integer) id;
	}

	// -----------------------------display data by I

	public Category getRowById(int id) {
		Session session = sessionFactory.openSession();
		Category category = (Category) session.load(Category.class, id);
		session.close();
		return category;
	}

}
