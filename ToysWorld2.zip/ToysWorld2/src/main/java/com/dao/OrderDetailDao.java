package com.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.google.gson.Gson;
import com.model.OrderDetails;
import com.model.Product;
import com.model.UserDetails;


@Repository
public class OrderDetailDao {
	@Autowired
	SessionFactory sessionFactory;

	public void saveOrder(OrderDetails o) {
		Session ses = sessionFactory.openSession();
		ses.beginTransaction();
		ses.save(o);
	     ses.getTransaction().commit();
		ses.close();
		
	}
//	public String getOrderDetail() {
//		// ------------------------new code addedd later for dynamic
//		// display---------------------
//		Session s = sessionFactory.openSession();
//		List spList = s.createQuery("from OrderDetails").list();
//		Gson g = new Gson();
//		String data = g.toJson(spList);
//		s.close();
//		return data;
//	
//}
	
	public String getOrderDetail(int oId)
	{
		Session session = sessionFactory.openSession();
		session.beginTransaction();
	    OrderDetails ru=( OrderDetails)session.get( OrderDetails.class,oId);
		session.getTransaction().commit();
		Gson g = new Gson();
	    String data = g.toJson(ru);
		session.close();
	   return data;
		
		
	}
}
