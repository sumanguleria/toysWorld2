package com.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.google.gson.Gson;
import com.model.Contact;

@Repository
public class ContactDao {
	@Autowired
	SessionFactory sessionFactory;

	// new addeddd---------------------------------------------Day12

	@Transactional
	public void addProduct(Contact cont) {
		Session ses = sessionFactory.openSession();
		ses.beginTransaction();
		ses.save(cont);
		System.out.println("Saveddddd data");
		ses.getTransaction().commit();
		ses.close();
		// SessionsessionFactory.getCurrentSession().save(pro);
	}
	public String getAllContact() {
		// ------------------------new code addedd later for dynamic
		// display---------------------
		Session s = sessionFactory.openSession();
		List spList = s.createQuery("from Contact").list();
		Gson g = new Gson();
		String data = g.toJson(spList);
		s.close();
		return data;
	}
}
