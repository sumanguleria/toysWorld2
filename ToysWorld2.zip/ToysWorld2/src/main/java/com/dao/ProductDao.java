package com.dao;

import com.google.gson.Gson;
import com.model.Category;
import com.model.Product;
import com.model.Supplier;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
//import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class ProductDao {

	@Autowired
	SessionFactory sessionFactory;

	// new addeddd---------------------------------------------Day6

	@Transactional
	public void addProduct(Product pro) {
		Session ses = sessionFactory.openSession();
		ses.beginTransaction();
		ses.save(pro);
		System.out.println("Saveddddd data");
		ses.getTransaction().commit();
		ses.close();
		// SessionsessionFactory.getCurrentSession().save(pro);
	}

	public String getAllProduct() {
		// ------------------------new code addedd later for dynamic
		// display---------------------
		Session s = sessionFactory.openSession();
		List spList = s.createQuery("from Product").list();
		Gson g = new Gson();
		String data = g.toJson(spList);
		s.close();
		return data;

		// ArrayList<Product> obj = new ArrayList();
		// Product p= new Product("Baby", 101, "Hello !Um Beautiful Baby
		// toyProduct description Lorem ipsum dolor sit amet, consectetuer
		// adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet
		// dolore magna aliquam erat volutpat.</p> ",1, 500.00,"baby");
		// Product p1= new Product("PokMon", 102, "Hello !Um PokMon here.....You
		// Wana Take Me ????? ",1, 500.00,"pkman");
		// Product p2= new Product("CarWithBaby", 103, "Hello !Um Beautiful
		// CarWithBabyToy ", 1,500.00,"gl2");
		// Product p3= new Product("Teddy", 103, "Hello !Um Beautiful Teddy ",
		// 1,500.00,"gl8");
		// obj.add(p);
		// obj.add(p1);
		// obj.add(p2);
		// obj.add(p3);
	}

	public void updateProject(Product pObj, int pId) {
		Session ses = sessionFactory.openSession();
		ses.beginTransaction();
		Product prObj = (Product) ses.get(Product.class, pId);
		prObj.setItemName(pObj.getItemName());
		prObj.setDiscription(pObj.getDiscription());
		prObj.setQty(pObj.getQty());
		prObj.setCategoryId(pObj.getCategoryId());
		prObj.setSupplierId(pObj.getSupplierId());
		prObj.setPrice(pObj.getPrice());
		ses.update(prObj);
		ses.getTransaction().commit();
		ses.close();

	}
	// -----------------------------display data by ID

	public Product getRowById(int id) {
		Session session = sessionFactory.openSession();
		Product product = (Product) session.get(Product.class, id);
		
		return product;
	}
	

	public void deleteProduct(int pId) {
		Session s = sessionFactory.openSession();
		s.beginTransaction();
		Product pObj = (Product) s.get(Product.class, pId);
		s.delete(pObj);
		s.getTransaction().commit();
		System.out.println("Data deleted " + pId);
		s.close();
	}
	
}
