package com.control;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.dao.SupplierDao;
import com.model.Category;
import com.model.Supplier;

@Controller
public class SupplierControler {

	// step 1 autowire
	@Autowired
	SupplierDao spDao;

	// step 2 method for get for first time method will load
	@RequestMapping(value = "/Supplier", method = RequestMethod.GET)
	public ModelAndView display() {
		System.out.print("Iside GET");
		String data = spDao.viewSupplier(); // retrieve data
		ModelAndView m = new ModelAndView("AddSupplier", "Supplier", new Supplier());
		m.addObject("spList", data);
		m.addObject("check",true);
		System.out.println(data);
		
		return m;
	}

	// step 2 method for post to submit data
	@RequestMapping(value = "/addSupplier", method = RequestMethod.POST)
	public ModelAndView addSupplier(Supplier spObj) {
		spDao.addSup(spObj);
		System.out.println("Supplier Data saved");
		String data = spDao.viewSupplier();
		ModelAndView m = new ModelAndView("AddSupplier", "Supplier", new Supplier());
		m.addObject("spList", data);
		m.addObject("check",true);

		return m;
	}

	// method for when we click on update link

	@RequestMapping(value = "/editSupplier", method = RequestMethod.GET)
	public ModelAndView updateSupplier(@RequestParam("spId") int sp) {
		System.out.print("Iside GET");
		Supplier spObject = spDao.viewSupplierById(sp); // retrieve data
		ModelAndView m = new ModelAndView("AddSupplier", "Supplier", spObject);
		m.addObject("spObject", spObject);
		m.addObject("check", false);
		System.out.println(sp + "inside dispUpdateSupplier ");

		return m;
	}

	// method for when we click on Update Button to update data
	@RequestMapping(value = "/updateSupplier", method = RequestMethod.POST)
	public ModelAndView updateSupplier(Supplier supObj) {
		int id = supObj.getSupplierId();
		System.out.println(id);
		spDao.updateSupplier(supObj, id);
		ModelAndView m = new ModelAndView("AddSupplier", "Supplier", new Supplier());
		String data = spDao.viewSupplier();
		m.addObject("spList", data);
		m.addObject("check", false);
		return m;

	}

	@RequestMapping(value = "/deleteSupplier", method = RequestMethod.GET)
	public ModelAndView deleteSupplier(@RequestParam("spId") int spId) {
		 spDao.deleteSupplier(spId);
		ModelAndView m = new ModelAndView("AddSupplier", "Supplier", new Supplier());
		String data = spDao.viewSupplier();
		m.addObject("spList", data);
		m.addObject("check", true);
		return m;

	}
}
